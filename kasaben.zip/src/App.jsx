import Header from './partials/header';
import Footer from './partials/footer';
import Home from './pages/home/home';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';


function App() {
  return (
    <>
      <BrowserRouter>
        <Header/>                           
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
        <Footer/>
      </BrowserRouter>
      </>
  );
}

export default App;
